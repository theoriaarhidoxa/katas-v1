const initialState = {
    loading: true,
    list: [],
    totalPages: 0,
    page: 0
};

export const kataReducer = (state = initialState, action) => {
    switch (action.type) {
        case 'SET_LOADING':
            return {...state, loading: action.payload};
        case 'SET_LIST':
            return {...state, list: action.payload};
        case 'SET_PAGE':
            return {...state, page: action.payload};
        case 'SET_TOTAL_PAGES':
            return {...state, totalPages: action.payload};
        default:
            return state;
    }
};
