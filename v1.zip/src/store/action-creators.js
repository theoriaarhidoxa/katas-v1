import {stringData} from "../App";

export const fetchKatas = page => {
    return async dispatch => {
        try {
            const res = await fetch(`${stringData.ALL_KATAS}${page}`);
            const katas = await res.json();
            dispatch({type: 'SET_LIST', payload: katas.data});
            dispatch({type: 'SET_TOTAL_PAGES', payload: katas['totalPages']});
        } catch (e) {
            console.log(e);
        } finally {
            dispatch({type: 'SET_LOADING', payload: false});
        }
    };
};

